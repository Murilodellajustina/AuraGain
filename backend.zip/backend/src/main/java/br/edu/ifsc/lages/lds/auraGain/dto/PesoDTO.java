package br.edu.ifsc.lages.lds.auraGain.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PesoDTO {

    private Long id;
    private Integer peso;

}
